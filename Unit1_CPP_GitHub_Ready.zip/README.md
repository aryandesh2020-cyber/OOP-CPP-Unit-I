# Unit 1 - C++ Programming Code Book

**Student:** Aryan Deshmukh  
**Roll No:** ET1122  
**Course:** B.Tech AI & DS  
**College:** Zeal College of Engineering

## Programs

1. Basic Data Types
2. if-else
3. Loop and Array
4. Functions
5. Class and Object
6. Constructor and Destructor
7. Static Member
8. Inline and Friend Function

Each program is provided as a separate `.cpp` file.
