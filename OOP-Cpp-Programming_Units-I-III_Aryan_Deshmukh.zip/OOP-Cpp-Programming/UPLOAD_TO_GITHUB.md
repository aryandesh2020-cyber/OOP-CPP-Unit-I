# Upload Guide

The package is prepared for the GitHub repository `OOP-Cpp-Programming`.

## Recommended workflow with VS Code / Git

1. Clone your existing GitHub repository:

```bash
git clone https://github.com/kshitijrathod/OOP-Cpp-Programming.git
cd OOP-Cpp-Programming
```

2. Copy the contents of this package into the cloned repository, replacing the root README with the prepared README when prompted.

3. Review the changes:

```bash
git status
git diff --stat
```

4. Make logical commits instead of one giant commit. Suggested sequence:

```text
Add Unit I programs and applications
Add Unit II inheritance programs and applications
Add Unit III polymorphism programs and applications
Add README and repository documentation
```

5. Push:

```bash
git add .
git commit -m "Add Unit I programs and applications"
git push origin main
```

Repeat the add/commit/push cycle for the remaining units.

## Notes

- The current GitHub repository already contains Unit I, Unit II and Unit III folder structures created through the web interface.
- Do not create a second repository.
- Keep the repository public so faculty can access it.
- The academic programs use C++17 or later.
